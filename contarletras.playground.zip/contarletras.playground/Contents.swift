//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"

extension String {
    var unique: String {
        var set = Set<Character>()
        return String(filter{ set.insert($0).inserted })
    }
}

extension String {
    func removingWhitespaces() -> String {
        return components(separatedBy: .whitespaces).joined()
    }
}

func arrayString (sentence: String) -> [Character]
{
    var arrayCharacters = [Character]()
    for char in sentence
    {
        arrayCharacters.append(char)
    }
    return arrayCharacters
}

func countLetter(sentence :String, char:Character) -> Int
{
    var count = 0
    for letter in sentence {
        if letter == char {
            count += 1
        }
    }
    return count
}

//Main

//sustituir por oracion deseada
let sentece = "i want to learn about it"
//quita espacios a la frase
let sentenceWSpace = sentece.removingWhitespaces()
//deja una frase con letras unicas
let uniqueSentence = sentenceWSpace.unique
//regresa un array con las letras
let uniqueArray = arrayString(sentence: uniqueSentence)

//impresion en pantalla
for characterC in 0..<uniqueArray.count
{
    print("Letra \(uniqueArray[characterC]) Repeticiones: \(countLetter(sentence: sentenceWSpace, char: uniqueArray[characterC]))")
}

